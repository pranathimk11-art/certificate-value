# CertificateVault

A MERN-stack learning record. Students keep every certificate, its expiry date and the work samples that prove the skill in one place.

**Differentiating feature:** certificates are flagged as *Valid*, *Expiring soon* (within 30 days) or *Expired*, and each certificate can be linked to the work samples (projects) that back it up.

## Tech stack
- **React** (Vite) for the UI, responsive down to phone width
- **Node.js + Express** REST API
- **MongoDB** (Mongoose) for persistence
- Input validation on both client and server, plus centralized error handling

## Features
- Add, edit, delete certificates (name, issuer, issue date, optional expiry date, credential link)
- Add, edit, delete work samples and link them to certificates
- Expiry warnings, summary banner and status filters
- Friendly validation and error messages

## Run it locally

### 1. Database
Create a free cluster on MongoDB Atlas, add a database user, allow your IP, and copy the connection string.

### 2. Backend
```bash
cd server
npm install
cp .env.example .env      # Windows: copy .env.example .env
# open .env and paste your MONGO_URI
npm run dev
```
The API runs on http://localhost:5000

### 3. Frontend (new terminal)
```bash
cd client
npm install
npm run dev
```
Open http://localhost:5173

## API

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | /api/certificates | List certificates (add `?status=expired`, `expiring`, `valid`) |
| POST | /api/certificates | Create a certificate |
| GET | /api/certificates/:id | Get one certificate |
| PUT | /api/certificates/:id | Update a certificate |
| DELETE | /api/certificates/:id | Delete a certificate |
| GET/POST | /api/projects | List / create work samples |
| PUT/DELETE | /api/projects/:id | Update / delete a work sample |

## Project structure
```
server/   Express API (models, routes, error middleware)
client/   React app (components, api helper, styles)
```

Author: PRANATHI M K (USN 2102508624)
