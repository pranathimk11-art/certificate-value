import { useEffect, useState, useCallback } from 'react';
import { api } from './api.js';
import Modal from './components/Modal.jsx';
import CertificateForm from './components/CertificateForm.jsx';
import CertificateRow from './components/CertificateRow.jsx';
import ProjectForm from './components/ProjectForm.jsx';

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'expiring', label: 'Expiring soon' },
  { key: 'expired', label: 'Expired' },
  { key: 'valid', label: 'Valid' },
];

export default function App() {
  const [tab, setTab] = useState('certificates');
  const [certs, setCerts] = useState([]);
  const [projects, setProjects] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  // modal: { type: 'cert' | 'project', item?: object } or null
  const [modal, setModal] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [c, p] = await Promise.all([api.getCertificates(), api.getProjects()]);
      setCerts(c);
      setProjects(p);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const close = () => setModal(null);

  const saveCert = async (data) => {
    if (modal.item) await api.updateCertificate(modal.item._id, data);
    else await api.createCertificate(data);
    close();
    load();
  };

  const saveProject = async (data) => {
    if (modal.item) await api.updateProject(modal.item._id, data);
    else await api.createProject(data);
    close();
    load();
  };

  const removeCert = async (cert) => {
    if (!window.confirm(`Delete "${cert.title}"? This cannot be undone.`)) return;
    try { await api.deleteCertificate(cert._id); load(); } catch (err) { setError(err.message); }
  };

  const removeProject = async (p) => {
    if (!window.confirm(`Delete "${p.title}"? It will be unlinked from any certificates.`)) return;
    try { await api.deleteProject(p._id); load(); } catch (err) { setError(err.message); }
  };

  const expired = certs.filter((c) => c.status === 'expired').length;
  const expiring = certs.filter((c) => c.status === 'expiring').length;
  const visible = filter === 'all' ? certs : certs.filter((c) => c.status === filter);

  return (
    <div className="page">
      <header className="top">
        <div>
          <h1>CertificateVault</h1>
          <p className="muted">Your certificates, renewal dates and proof of work in one place.</p>
        </div>
        <button
          className="btn"
          onClick={() => setModal({ type: tab === 'certificates' ? 'cert' : 'project' })}
        >
          {tab === 'certificates' ? 'Add certificate' : 'Add work sample'}
        </button>
      </header>

      {!loading && (expired > 0 || expiring > 0) && (
        <section className="summary" aria-live="polite">
          {expired > 0 && <p className="s-expired"><strong>{expired}</strong> expired, renew or archive</p>}
          {expiring > 0 && <p className="s-expiring"><strong>{expiring}</strong> expiring within 30 days</p>}
        </section>
      )}

      <nav className="tabs" aria-label="Sections">
        <button className={tab === 'certificates' ? 'active' : ''} onClick={() => setTab('certificates')}>
          Certificates ({certs.length})
        </button>
        <button className={tab === 'projects' ? 'active' : ''} onClick={() => setTab('projects')}>
          Work samples ({projects.length})
        </button>
      </nav>

      {error && (
        <p className="alert" role="alert">
          {error} <button className="link-btn" onClick={load}>Try again</button>
        </p>
      )}

      {loading ? (
        <p className="muted">Loading…</p>
      ) : tab === 'certificates' ? (
        <>
          <div className="filters">
            {FILTERS.map((f) => (
              <button key={f.key} className={filter === f.key ? 'pill active' : 'pill'} onClick={() => setFilter(f.key)}>
                {f.label}
              </button>
            ))}
          </div>
          {visible.length === 0 ? (
            <div className="empty">
              <p>{certs.length === 0 ? 'No certificates yet. Add your first one to start tracking renewals.' : 'Nothing matches this filter.'}</p>
            </div>
          ) : (
            <ul className="list">
              {visible.map((c) => (
                <CertificateRow key={c._id} cert={c} onEdit={(item) => setModal({ type: 'cert', item })} onDelete={removeCert} />
              ))}
            </ul>
          )}
        </>
      ) : projects.length === 0 ? (
        <div className="empty">
          <p>No work samples yet. Add a project, then link it to the certificates it backs up.</p>
        </div>
      ) : (
        <ul className="list">
          {projects.map((p) => {
            const used = certs.filter((c) => c.projects.some((x) => x._id === p._id));
            return (
              <li key={p._id} className="cert no-expiry">
                <div className="cert-main">
                  <h3>{p.title}</h3>
                  {p.description && <p>{p.description}</p>}
                  {p.url && <a href={p.url} target="_blank" rel="noreferrer">Open link</a>}
                  <p className="muted">
                    {used.length === 0 ? 'Not linked to any certificate' : `Backs up: ${used.map((c) => c.title).join(', ')}`}
                  </p>
                </div>
                <div className="cert-side">
                  <div className="row-actions">
                    <button className="link-btn" onClick={() => setModal({ type: 'project', item: p })}>Edit</button>
                    <button className="link-btn danger" onClick={() => removeProject(p)}>Delete</button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {modal?.type === 'cert' && (
        <Modal title={modal.item ? 'Edit certificate' : 'Add certificate'} onClose={close}>
          <CertificateForm initial={modal.item} projects={projects} onSubmit={saveCert} onCancel={close} />
        </Modal>
      )}
      {modal?.type === 'project' && (
        <Modal title={modal.item ? 'Edit work sample' : 'Add work sample'} onClose={close}>
          <ProjectForm initial={modal.item} onSubmit={saveProject} onCancel={close} />
        </Modal>
      )}
    </div>
  );
}
