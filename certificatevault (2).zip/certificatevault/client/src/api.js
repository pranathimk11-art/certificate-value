// All communication with the backend lives here.
const BASE = '/api';

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(BASE + path, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
  } catch {
    throw new Error('Cannot reach the server. Check that the backend is running.');
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.message || 'Something went wrong.');
    err.fields = data.errors || {};
    throw err;
  }
  return data;
}

const json = (method, body) => ({ method, body: JSON.stringify(body) });

export const api = {
  getCertificates: () => request('/certificates'),
  createCertificate: (d) => request('/certificates', json('POST', d)),
  updateCertificate: (id, d) => request(`/certificates/${id}`, json('PUT', d)),
  deleteCertificate: (id) => request(`/certificates/${id}`, { method: 'DELETE' }),

  getProjects: () => request('/projects'),
  createProject: (d) => request('/projects', json('POST', d)),
  updateProject: (id, d) => request(`/projects/${id}`, json('PUT', d)),
  deleteProject: (id) => request(`/projects/${id}`, { method: 'DELETE' }),
};
