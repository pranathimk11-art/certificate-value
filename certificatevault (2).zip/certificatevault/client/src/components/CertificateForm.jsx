import { useState } from 'react';

const toInputDate = (d) => (d ? new Date(d).toISOString().slice(0, 10) : '');
const urlOk = (v) => !v || /^https?:\/\/\S+$/i.test(v);

export default function CertificateForm({ initial, projects, onSubmit, onCancel }) {
  const [form, setForm] = useState({
    title: initial?.title || '',
    issuer: initial?.issuer || '',
    issueDate: toInputDate(initial?.issueDate),
    expiryDate: toInputDate(initial?.expiryDate),
    credentialUrl: initial?.credentialUrl || '',
    projects: initial?.projects?.map((p) => p._id) || [],
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const toggleProject = (id) =>
    setForm({
      ...form,
      projects: form.projects.includes(id)
        ? form.projects.filter((p) => p !== id)
        : [...form.projects, id],
    });

  // Client-side validation (the server validates again)
  const validate = () => {
    const e = {};
    if (form.title.trim().length < 2) e.title = 'Enter the certificate name (at least 2 characters).';
    if (!form.issuer.trim()) e.issuer = 'Enter who issued it.';
    if (!form.issueDate) e.issueDate = 'Pick the issue date.';
    if (form.expiryDate && form.issueDate && form.expiryDate <= form.issueDate)
      e.expiryDate = 'Expiry date must be after the issue date.';
    if (!urlOk(form.credentialUrl.trim())) e.credentialUrl = 'Link must start with http:// or https://';
    return e;
  };

  const submit = async (ev) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    setFormError('');
    if (Object.keys(e).length) return;
    setSaving(true);
    try {
      await onSubmit({ ...form, title: form.title.trim(), issuer: form.issuer.trim(), credentialUrl: form.credentialUrl.trim() });
    } catch (err) {
      setErrors(err.fields || {});
      setFormError(err.message);
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} noValidate>
      {formError && <p className="alert" role="alert">{formError}</p>}

      <label>
        Certificate name
        <input value={form.title} onChange={set('title')} placeholder="AWS Cloud Practitioner" />
        {errors.title && <span className="field-error">{errors.title}</span>}
      </label>

      <label>
        Issued by
        <input value={form.issuer} onChange={set('issuer')} placeholder="Amazon Web Services" />
        {errors.issuer && <span className="field-error">{errors.issuer}</span>}
      </label>

      <div className="row">
        <label>
          Issue date
          <input type="date" value={form.issueDate} onChange={set('issueDate')} />
          {errors.issueDate && <span className="field-error">{errors.issueDate}</span>}
        </label>
        <label>
          Expiry date (optional)
          <input type="date" value={form.expiryDate} onChange={set('expiryDate')} />
          {errors.expiryDate && <span className="field-error">{errors.expiryDate}</span>}
        </label>
      </div>

      <label>
        Credential link (optional)
        <input value={form.credentialUrl} onChange={set('credentialUrl')} placeholder="https://..." />
        {errors.credentialUrl && <span className="field-error">{errors.credentialUrl}</span>}
      </label>

      <fieldset>
        <legend>Work samples that use this skill</legend>
        {projects.length === 0 ? (
          <p className="muted">No work samples yet. Add some in the Work samples tab, then link them here.</p>
        ) : (
          <div className="checks">
            {projects.map((p) => (
              <label key={p._id} className="check">
                <input
                  type="checkbox"
                  checked={form.projects.includes(p._id)}
                  onChange={() => toggleProject(p._id)}
                />
                {p.title}
              </label>
            ))}
          </div>
        )}
      </fieldset>

      <div className="actions">
        <button type="button" className="btn ghost" onClick={onCancel}>Cancel</button>
        <button type="submit" className="btn" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Save changes' : 'Add certificate'}
        </button>
      </div>
    </form>
  );
}
