const fmt = (d) =>
  new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });

function statusText(c) {
  if (c.status === 'expired') return `Expired ${Math.abs(c.daysLeft)} day${Math.abs(c.daysLeft) === 1 ? '' : 's'} ago`;
  if (c.status === 'expiring') return c.daysLeft === 0 ? 'Expires today' : `Renew in ${c.daysLeft} day${c.daysLeft === 1 ? '' : 's'}`;
  if (c.status === 'valid') return `Valid until ${fmt(c.expiryDate)}`;
  return 'No expiry';
}

export default function CertificateRow({ cert, onEdit, onDelete }) {
  return (
    <li className={`cert ${cert.status}`}>
      <div className="cert-main">
        <h3>{cert.title}</h3>
        <p className="muted">
          {cert.issuer}, issued {fmt(cert.issueDate)}
        </p>
        {cert.credentialUrl && (
          <a href={cert.credentialUrl} target="_blank" rel="noreferrer">View credential</a>
        )}
        {cert.projects.length > 0 && (
          <div className="samples">
            <span className="muted">Work samples:</span>
            {cert.projects.map((p) =>
              p.url ? (
                <a key={p._id} className="chip" href={p.url} target="_blank" rel="noreferrer">{p.title}</a>
              ) : (
                <span key={p._id} className="chip">{p.title}</span>
              )
            )}
          </div>
        )}
      </div>
      <div className="cert-side">
        <span className={`badge ${cert.status}`}>{statusText(cert)}</span>
        <div className="row-actions">
          <button className="link-btn" onClick={() => onEdit(cert)}>Edit</button>
          <button className="link-btn danger" onClick={() => onDelete(cert)}>Delete</button>
        </div>
      </div>
    </li>
  );
}
