import { useState } from 'react';

export default function ProjectForm({ initial, onSubmit, onCancel }) {
  const [form, setForm] = useState({
    title: initial?.title || '',
    description: initial?.description || '',
    url: initial?.url || '',
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const validate = () => {
    const e = {};
    if (form.title.trim().length < 2) e.title = 'Enter a title (at least 2 characters).';
    if (form.description.length > 500) e.description = 'Keep the description under 500 characters.';
    if (form.url.trim() && !/^https?:\/\/\S+$/i.test(form.url.trim()))
      e.url = 'Link must start with http:// or https://';
    return e;
  };

  const submit = async (ev) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    setFormError('');
    if (Object.keys(e).length) return;
    setSaving(true);
    try {
      await onSubmit({ ...form, title: form.title.trim(), url: form.url.trim() });
    } catch (err) {
      setErrors(err.fields || {});
      setFormError(err.message);
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} noValidate>
      {formError && <p className="alert" role="alert">{formError}</p>}

      <label>
        Title
        <input value={form.title} onChange={set('title')} placeholder="Serverless photo gallery" />
        {errors.title && <span className="field-error">{errors.title}</span>}
      </label>

      <label>
        What did you build?
        <textarea rows="3" value={form.description} onChange={set('description')} />
        {errors.description && <span className="field-error">{errors.description}</span>}
      </label>

      <label>
        Link (GitHub, live demo)
        <input value={form.url} onChange={set('url')} placeholder="https://github.com/..." />
        {errors.url && <span className="field-error">{errors.url}</span>}
      </label>

      <div className="actions">
        <button type="button" className="btn ghost" onClick={onCancel}>Cancel</button>
        <button type="submit" className="btn" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Save changes' : 'Add work sample'}
        </button>
      </div>
    </form>
  );
}
