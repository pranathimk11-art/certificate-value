// Turns any error into a clean JSON response the frontend can show.
module.exports = (err, req, res, next) => {
  if (err.name === 'ValidationError') {
    const errors = {};
    Object.values(err.errors).forEach((e) => (errors[e.path] = e.message));
    return res.status(400).json({ message: 'Please fix the highlighted fields.', errors });
  }
  if (err.name === 'CastError') {
    return res.status(400).json({ message: 'Invalid ID format.' });
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Request body is not valid JSON.' });
  }
  console.error(err);
  res.status(500).json({ message: 'Server error. Please try again.' });
};
