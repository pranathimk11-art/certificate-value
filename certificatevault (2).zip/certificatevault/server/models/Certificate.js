const mongoose = require('mongoose');

const urlPattern = /^https?:\/\/[^\s$.?#].[^\s]*$/i;

const certificateSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Certificate name is required'],
      trim: true,
      minlength: [2, 'Name must be at least 2 characters'],
      maxlength: [120, 'Name must be at most 120 characters'],
    },
    issuer: {
      type: String,
      required: [true, 'Issuer is required'],
      trim: true,
      maxlength: [100, 'Issuer must be at most 100 characters'],
    },
    issueDate: {
      type: Date,
      required: [true, 'Issue date is required'],
    },
    expiryDate: {
      type: Date,
      default: null,
      validate: {
        validator: function (v) {
          return !v || !this.issueDate || v > this.issueDate;
        },
        message: 'Expiry date must be after the issue date',
      },
    },
    credentialUrl: {
      type: String,
      trim: true,
      default: '',
      validate: {
        validator: (v) => !v || urlPattern.test(v),
        message: 'Link must start with http:// or https://',
      },
    },
    projects: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Project' }],
  },
  { timestamps: true }
);

const DAY = 24 * 60 * 60 * 1000;
const EXPIRING_SOON_DAYS = 30;

// Adds status + daysLeft so the frontend can show warnings.
certificateSchema.methods.toClient = function () {
  const obj = this.toObject();
  if (!obj.expiryDate) {
    obj.status = 'no-expiry';
    obj.daysLeft = null;
  } else {
    const daysLeft = Math.ceil((new Date(obj.expiryDate) - Date.now()) / DAY);
    obj.daysLeft = daysLeft;
    obj.status = daysLeft < 0 ? 'expired' : daysLeft <= EXPIRING_SOON_DAYS ? 'expiring' : 'valid';
  }
  return obj;
};

module.exports = mongoose.model('Certificate', certificateSchema);
