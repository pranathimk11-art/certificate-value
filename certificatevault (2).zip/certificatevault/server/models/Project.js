const mongoose = require('mongoose');

const urlPattern = /^https?:\/\/[^\s$.?#].[^\s]*$/i;

const projectSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      minlength: [2, 'Title must be at least 2 characters'],
      maxlength: [100, 'Title must be at most 100 characters'],
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description must be at most 500 characters'],
      default: '',
    },
    url: {
      type: String,
      trim: true,
      default: '',
      validate: {
        validator: (v) => !v || urlPattern.test(v),
        message: 'Link must start with http:// or https://',
      },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Project', projectSchema);
