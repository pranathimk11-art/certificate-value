const express = require('express');
const Certificate = require('../models/Certificate');
const Project = require('../models/Project');

const router = express.Router();

const FIELDS = ['title', 'issuer', 'issueDate', 'expiryDate', 'credentialUrl', 'projects'];

// Pick only the fields we allow from the request body
const pick = (body) => {
  const data = {};
  FIELDS.forEach((f) => {
    if (body[f] !== undefined) data[f] = body[f];
  });
  if (data.expiryDate === '') data.expiryDate = null;
  return data;
};

// Make sure every linked project really exists
async function checkProjects(ids) {
  if (!ids || ids.length === 0) return;
  const count = await Project.countDocuments({ _id: { $in: ids } });
  if (count !== new Set(ids.map(String)).size) {
    const err = new Error('One or more linked projects do not exist.');
    err.status = 400;
    throw err;
  }
}

const sendClientError = (err, res, next) =>
  err.status ? res.status(err.status).json({ message: err.message }) : next(err);

// GET all (optional ?status=expired|expiring|valid|no-expiry)
router.get('/', async (req, res, next) => {
  try {
    const certs = await Certificate.find().populate('projects').sort({ expiryDate: 1, issueDate: -1 });
    let list = certs.map((c) => c.toClient());
    if (req.query.status) list = list.filter((c) => c.status === req.query.status);
    res.json(list);
  } catch (err) {
    next(err);
  }
});

// GET one
router.get('/:id', async (req, res, next) => {
  try {
    const cert = await Certificate.findById(req.params.id).populate('projects');
    if (!cert) return res.status(404).json({ message: 'Certificate not found.' });
    res.json(cert.toClient());
  } catch (err) {
    next(err);
  }
});

// CREATE
router.post('/', async (req, res, next) => {
  try {
    const data = pick(req.body);
    await checkProjects(data.projects);
    const cert = await Certificate.create(data);
    await cert.populate('projects');
    res.status(201).json(cert.toClient());
  } catch (err) {
    sendClientError(err, res, next);
  }
});

// UPDATE
router.put('/:id', async (req, res, next) => {
  try {
    const cert = await Certificate.findById(req.params.id);
    if (!cert) return res.status(404).json({ message: 'Certificate not found.' });
    const data = pick(req.body);
    await checkProjects(data.projects);
    cert.set(data);
    await cert.save(); // runs validators
    await cert.populate('projects');
    res.json(cert.toClient());
  } catch (err) {
    sendClientError(err, res, next);
  }
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  try {
    const cert = await Certificate.findByIdAndDelete(req.params.id);
    if (!cert) return res.status(404).json({ message: 'Certificate not found.' });
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
