const express = require('express');
const Project = require('../models/Project');
const Certificate = require('../models/Certificate');

const router = express.Router();

const pick = ({ title, description, url }) => {
  const data = {};
  if (title !== undefined) data.title = title;
  if (description !== undefined) data.description = description;
  if (url !== undefined) data.url = url;
  return data;
};

router.get('/', async (req, res, next) => {
  try {
    res.json(await Project.find().sort({ createdAt: -1 }));
  } catch (err) {
    next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    res.status(201).json(await Project.create(pick(req.body)));
  } catch (err) {
    next(err);
  }
});

router.put('/:id', async (req, res, next) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found.' });
    project.set(pick(req.body));
    await project.save();
    res.json(project);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const project = await Project.findByIdAndDelete(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found.' });
    // Remove the link from any certificate that used it
    await Certificate.updateMany({ projects: project._id }, { $pull: { projects: project._id } });
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
